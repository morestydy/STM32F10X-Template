#include "led.h"
#include "timer.h"

int main(void)
{
  u8 led_state;
  SystemInit();         //��ʼ��ϵͳ,ʹϵͳƵ��Ϊ72MHz
  systick_init();        //1ms�ж�
  led_gpio_init();
  key_init();


  while(1)
  {
    if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4)==RESET)
    {
      delay_ms(10);
      if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4)==RESET)
      {
        led_state=led_state>=4?0:led_state+1;
      }while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11) == RESET);
    }
    
    if((led_state%2)==1)
    {
      GPIO_SetBits(GPIOB,GPIO_Pin_5);
    }
    else{
      GPIO_ResetBits(GPIOB,GPIO_Pin_5);
    }
  }
}
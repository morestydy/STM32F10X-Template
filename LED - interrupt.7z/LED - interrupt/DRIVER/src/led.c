#include "led.h"

/*
����: 
  1. ����RCC,ʹ��GPIO
*/



void led_gpio_init(void)
{
  GPIO_InitTypeDef GPIO_InitSructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
  
  GPIO_InitSructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitSructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitSructure.GPIO_Speed = GPIO_Speed_50MHz;
  
  /*��ʼ��GPIO*/

  GPIO_Init(GPIOB,&GPIO_InitSructure);
}
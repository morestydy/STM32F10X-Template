#include "key.h"
#include "led.h"

u8 led_on_off;
void key_gpio_init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  EXTI_InitTypeDef EXTI_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  
  RCC_APB2PeriphResetCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO,ENABLE);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB,&GPIO_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource5); 
  
  EXTI_InitStructure.EXTI_Line = EXTI_Line11;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0); //���������ȼ�
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn; //�ⲿ�ж���
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; //������ռ���ȼ�
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0; //���������ȼ�
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //ʹ�� IRQ �ж�
  NVIC_Init(&NVIC_InitStructure);
  
}

void EXTI15_10_IRQHandler(void)
{
  u8 i,j;
  if(EXTI_GetFlagStatus(EXTI_Line11) != RESET)
  {
    for (i=100; i>0; i--)
      for (j=720;j>0;j--);
    if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) == RESET)
      led_on_off = led_on_off >= 4 ? 0 : led_on_off + 1;
    if (led_on_off % 2 == 1)
    {
      GPIO_SetBits(GPIOB, GPIO_Pin_5);
    }
    else
      GPIO_ResetBits(GPIOB, GPIO_Pin_5);
    EXTI_ClearITPendingBit(EXTI_Line11);
  }
  
}

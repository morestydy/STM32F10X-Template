#ifndef _KEY_H_
#define _KEY_H_
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"

void key_gpio_init(void);


#endif
#ifndef _TIMER_H_
#define _TIMER_H_
#include "stm32f10x.h"
void systick_init(void);
void delay_ms(__IO uint32_t nTime);

extern __IO uint32_t TimngDelay;

#endif
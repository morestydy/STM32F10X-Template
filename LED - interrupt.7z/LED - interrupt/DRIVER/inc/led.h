#ifndef _LED_H_
#define _LED_H_

#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_exti.h"


void led_gpio_init(void);


#endif
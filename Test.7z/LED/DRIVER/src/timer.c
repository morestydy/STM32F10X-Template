#include "timer.h"

__IO uint32_t TimngDelay;

void systick_init(void)
{
  /*����systick������ֵ,ϵͳʱ��72MHz*/
  /*����72000,�ж�ʱ��:72000 * (1/72000000) = 1ms*/
  if(SysTick_Config(72000) == 1)
  {
    while(1);
  }
  /*
  while(SysTick_Config(72000) == 1);
  */
}
void TimngDelay_Decrment(void)
{
  if (TimngDelay != 0x0)
  {
    TimngDelay--;
  }
}

void SysTick_Handler(void)
{
  TimngDelay_Decrment(); 
}
void delay_ms(__IO uint32_t nTime)
{
  TimngDelay = nTime;//ʱ�ӵδ���
  while(TimngDelay != 0);
}
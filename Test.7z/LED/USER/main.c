#include "led.h"
#include "timer.h"

int main(void)
{
  
  SystemInit();         //��ʼ��ϵͳ,ʹϵͳƵ��Ϊ72MHz
  systick_init();        //1ms�ж�
  led_gpio_init();


  while(1)
  {
     GPIO_SetBits(GPIOB,GPIO_Pin_5);
     delay_ms(1000);
     GPIO_ResetBits(GPIOB,GPIO_Pin_5);
     delay_ms(1000);
  }
}
#include "key.h"


void key_init(void)
{
  GPIO_InitTypeDef GPIO_InitSructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
  GPIO_InitSructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitSructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4;
//  GPIO_InitSructure.GPIO_Speed =
  
  
  GPIO_Init(GPIOE,&GPIO_InitSructure);

}
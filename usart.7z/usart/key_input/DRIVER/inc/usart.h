#ifndef _USART_H_
#define _USART_H_


#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"


void usart_init(void);

#endif